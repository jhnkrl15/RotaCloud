import { Component, OnInit } from '@angular/core';
import { forkJoin, Observable } from 'rxjs';
import { Role } from '../models/role';
import { User } from '../models/user';
import { UserWithRoles } from '../models/user-with-roles';
import { RoleService } from '../services/role-service';
import { UserService } from '../services/user-service';

@Component({
  selector: 'app-users',
  templateUrl: './users.component.html',
  styleUrls: ['./users.component.css']
})
export class UsersComponent implements OnInit {
  userList: User[];
  roleList: Role[];
  usersWithRoles: UserWithRoles[];
  roles: Role[];

  constructor(private userService: UserService, private roleService: RoleService) { }

  ngOnInit() {
    this.getUserWithRoles();
  }

  getUserWithRoles() {
    let userList = this.userService.get();
    let roleList = this.roleService.get();

    forkJoin([userList, roleList]).subscribe(([users, roles]) => {
      this.usersWithRoles = [];
      this.userList = users;
      this.roleList = roles;

      this.userList.forEach(user => {
        this.roles = [];

        if (user.roles != null) {
          user.roles.forEach(id => {
            var role = this.getRoleById(id);
            this.roles.push(role);
          });
        }
        var userRole = new UserWithRoles(user.id, user.name, this.roles);

        this.usersWithRoles.push(userRole);
      });

      this.usersWithRoles = this.usersWithRoles.sort(function (a, b) {
        if (a.name < b.name) {
          return -1;
        }
        if (a.name > b.name) {
          return 1;
        }
        return 0;
      });
    });
  }

  getRoleById(id: number): Role {
    var role = this.roleList.find(x => x.id == id);
    return role;
  }

  onBlur(row: User, event: any) {
    var newName = event.target.value;
    if (newName == "") {
      alert("Please input a value!");
    }
    else {
      var user = this.userService.userList.find(x => x.id == row.id);
  
      if (user.name != newName) {
        var index = this.userService.userList.map(object => object.id).indexOf(row.id);
        if (index !== -1) {
          user.name = newName;
          this.userService.userList[index] = user;
          this.getUserWithRoles();
        }
      }
    }
  }

}
