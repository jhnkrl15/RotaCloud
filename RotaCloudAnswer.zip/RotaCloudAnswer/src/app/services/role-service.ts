import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable, of, throwError } from 'rxjs';
import { catchError, map } from 'rxjs/operators';
import { Role } from '../models/role';

@Injectable()

export class RoleService {
    roleList: Role[];

    constructor(private http: HttpClient) {
    }

    get(): Observable<Role[]> {
        if (!!!this.roleList) {
            return this.http.get<Role[]>(`https://custom.rotacloud.com/angular-challenge/roles.json`).pipe(
                map(data => this.roleList = data as Role[]),
                catchError(this.erroHandler));
        }
        return of(this.roleList);
    }

    erroHandler(error: HttpErrorResponse) {
        return throwError(error.message || 'server Error');
    }
}