import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable, of, throwError } from 'rxjs';
import { catchError, map } from 'rxjs/operators';
import { User } from '../models/user';


@Injectable()

export class UserService {

    userList: User[];

    constructor(private http: HttpClient) {
    }

    get(): Observable<User[]> {
        if (!!!this.userList) {
            return this.http.get<User[]>(`https://custom.rotacloud.com/angular-challenge/users.json`).pipe(
                map(data => this.userList = data as User[]),
                catchError(this.erroHandler));
        }
        return of(this.userList);
    }

    erroHandler(error: HttpErrorResponse) {
        return throwError(error.message || 'server Error');
    }
}