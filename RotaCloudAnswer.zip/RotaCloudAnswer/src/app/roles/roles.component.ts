import { Component, OnInit } from '@angular/core';
import { forkJoin } from 'rxjs';
import { Role } from '../models/role';
import { RoleWithUsers } from '../models/role-with-users';
import { User } from '../models/user';
import { RoleService } from '../services/role-service';
import { UserService } from '../services/user-service';

@Component({
  selector: 'app-roles',
  templateUrl: './roles.component.html',
  styleUrls: ['./roles.component.css']
})
export class RolesComponent implements OnInit {
  userList: User[];
  roleList: Role[];
  rolesWithUser: RoleWithUsers[];
  users: Role[];

  constructor(private roleService: RoleService, private userService: UserService) { }

  ngOnInit() {
    this.getRolesWithUser();
  }

  getRolesWithUser() {
    let userList = this.userService.get();
    let roleList = this.roleService.get();

    forkJoin([userList, roleList]).subscribe(([users, roles]) => {
      this.rolesWithUser = [];
      this.userList = users;
      this.roleList = roles;

      this.roleList.forEach(role => {
        var userRole = new RoleWithUsers(role.id, role.name, role.colour, []);
        this.rolesWithUser.push(userRole);
      });

      this.userList.forEach(user => {
        if (user.roles != null) {
          user.roles.forEach(roleId => {
            var role = this.rolesWithUser.find(x => x.id == roleId);
            if (role) {
              role.users.push(user);
            }
          });
        }
      });

      var sortedRolesWithUser = this.rolesWithUser.sort(function (a, b) {
        if (a.name < b.name) {
          return -1;
        }
        if (a.name > b.name) {
          return 1;
        }
        return 0;
      });

      sortedRolesWithUser.forEach(role => {
        role.users = role.users.sort(function (a, b) {
          if (a.name < b.name) {
            return -1;
          }
          if (a.name > b.name) {
            return 1;
          }
          return 0;
        });
      });

      this.rolesWithUser = sortedRolesWithUser;
    });
  }

  onBlur(row: Role, event: any) {
    var newName = event.target.value;
    if (newName == "") {
      alert("Please input a value!");
    }
    else {
      var role = this.roleService.roleList.find(x => x.id == row.id);

      if (role.name != newName) {
        var index = this.roleService.roleList.map(object => object.id).indexOf(row.id);
        if (index !== -1) {
          row.name = newName;
          this.roleService.roleList[index] = row;
          this.getRolesWithUser();
        }
      }
    }
  }

}
