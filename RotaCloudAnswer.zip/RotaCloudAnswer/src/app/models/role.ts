export class Role {
    id: number;
    name: string;
    colour: string;
}