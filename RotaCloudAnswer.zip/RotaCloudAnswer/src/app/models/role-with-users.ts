import { Role } from "./role";
import { User } from "./user";

export class RoleWithUsers {
    id: number;
    name: string;
    colour: string;
    users: User[];

    constructor(id: number, name: string, colour: string, users: User[]) {
        this.id = id;
        this.name = name;
        this.colour = colour;
        this.users = users;
    }
}