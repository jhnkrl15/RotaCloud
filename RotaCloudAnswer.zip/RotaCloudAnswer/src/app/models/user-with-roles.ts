import { Role } from "./role";

export class UserWithRoles {
    id: number;
    name: string;
    roles: Role[];

    constructor(id: number, name: string, roles: Role[]) {
        this.id = id;
        this.name = name;
        this.roles = roles;
    }
}