export class User{
    id: number;
    name: string;
    roles: number[];
}